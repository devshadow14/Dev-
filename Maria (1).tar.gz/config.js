// config.js
export default {
    // Préfixe du bot
    PREFIX: "👾",
    
    // Nom du bot
    BOT_NAME: "𝙼𝙰𝚁𝙸𝙰 𝚇𝙳",
    
    // Numéros des owners (admin)
    OWNERS: [
        "24177474264@s.whatsapp.net", // Remplacez par votre numéro
    ],
    
    // Paramètres du bot
    SETTINGS: {
        ANTI_LIEN: false,
        ANTI_PROMOTE: false,
        WELCOME: true,
        GOODBYE: true
    },
    
    // Messages automatiques
    AUTO_MESSAGES: {
        WELCOME: "Bienvenue dans le groupe ! 🎉",
        GOODBYE: "Au revoir ! 👋"
    }
};